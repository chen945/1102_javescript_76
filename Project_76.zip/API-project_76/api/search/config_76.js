export const searchItems = ["2115888", "2115887", "2115886"];

export const hasNetwork = true;

export const LOCAL_URL = "/api/search/";
